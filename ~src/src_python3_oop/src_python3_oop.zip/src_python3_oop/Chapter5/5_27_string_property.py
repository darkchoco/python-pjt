    @property
    def string(self):
        return "".join(self.characters)
