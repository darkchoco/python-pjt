class MyObject:
    pass
