print("{} {label} {}".format("x", "y", label="z"))
