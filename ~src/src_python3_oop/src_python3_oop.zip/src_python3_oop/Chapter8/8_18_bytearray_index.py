b = bytearray(b'abcdef')
b[3] = ord(b'g')
b[4] = 68
print(b)
