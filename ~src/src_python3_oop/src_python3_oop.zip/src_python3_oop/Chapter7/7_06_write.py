contents = "Some file contents"
file = open("filename", "w")
file.write(contents)
file.close()
