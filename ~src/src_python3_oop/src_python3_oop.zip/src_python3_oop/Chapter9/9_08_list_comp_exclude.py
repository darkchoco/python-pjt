input_strings = ['1', '5', '28', '131', '3']

output_integers = [int(n) for n in input_strings if len(n) < 3]
